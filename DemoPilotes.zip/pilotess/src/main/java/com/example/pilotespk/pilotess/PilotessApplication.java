package com.example.pilotespk.pilotess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PilotessApplication {

	public static void main(String[] args) {
		SpringApplication.run(PilotessApplication.class, args);
	}

}
